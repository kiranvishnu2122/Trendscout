import tensorflow as tf
import numpy as np
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.preprocessing import image
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import requests
from PIL import Image
from io import BytesIO
import logging

class ImageAnalyzer:
    def __init__(self):
        # Load pre-trained ResNet50 model, excluding the top classification layer
        self.model = ResNet50(weights='imagenet', include_top=False, pooling='avg')
        
    def extract_features(self, img_path):
        """Extract features from an image using ResNet50."""
        # Load and preprocess the image
        if isinstance(img_path, str):
            img = image.load_img(img_path, target_size=(224, 224))
        else:
            img = Image.open(img_path)
            img = img.resize((224, 224))
        
        # Convert image to array and preprocess
        img_array = image.img_to_array(img)
        img_array = np.expand_dims(img_array, axis=0)
        img_array = preprocess_input(img_array)
        
        # Extract features using the model
        features = self.model.predict(img_array)
        return features.flatten()
    
    def compare_features(self, features1, features2):
        """Compare two feature vectors using cosine similarity."""
        similarity = np.dot(features1, features2) / (
            np.linalg.norm(features1) * np.linalg.norm(features2)
        )
        return similarity

class ProductScraper:
    def __init__(self):
        # Configure Chrome options for headless operation
        chrome_options = Options()
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        self.driver = webdriver.Chrome(options=chrome_options)
        self.image_analyzer = ImageAnalyzer()
        self.logger = logging.getLogger(__name__)
        
    def get_product_categories(self, image_features):
        """Use image features to determine relevant product categories."""
        # Here you could implement category classification
        # For now, we'll use some general product categories
        return ['electronics', 'clothing', 'accessories', 'home']
    
    def search_amazon(self, image_features, categories):
        """Search Amazon for visually similar products and include ratings and delivery dates."""
        products = []
        
        for category in categories:
            try:
                url = f"https://www.amazon.in/s?k={category}"
                self.driver.get(url)
                
                # Wait for product elements to load
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, '.s-result-item'))
                )
                
                soup = BeautifulSoup(self.driver.page_source, 'html.parser')
                
                for item in soup.select('.s-result-item'):
                    try:
                        # Extract product information
                        title_elem = item.select_one('.a-text-normal')
                        price_elem = item.select_one('.a-price-whole')
                        img_elem = item.select_one('img.s-image')
                        rating_elem = item.select_one('.a-icon-alt')  # Extract ratings
                        delivery_elem = item.select_one('.a-text-bold + span')  # Extract delivery date
                        
                        if not all([title_elem, price_elem, img_elem]):
                            continue
                            
                        title = title_elem.text
                        price = price_elem.text
                        img_url = img_elem['src']
                        product_url = 'https://amazon.in' + item.select_one('a.a-link-normal')['href']
                        rating = rating_elem.text if rating_elem else 'No ratings'
                        delivery_date = delivery_elem.text if delivery_elem else 'Delivery info unavailable'
                        
                        # Download and analyze product image
                        response = requests.get(img_url)
                        img_content = BytesIO(response.content)
                        product_features = self.image_analyzer.extract_features(img_content)
                        
                        # Calculate similarity with uploaded image
                        similarity = self.image_analyzer.compare_features(image_features, product_features)
                        
                        if similarity > 0.5:  # Only include products with significant similarity
                            products.append({
                                'title': title,
                                'price': float(price.replace(',', '')),
                                'url': product_url,
                                'image_url': img_url,
                                'rating': rating,
                                'delivery_date': delivery_date,
                                'similarity': similarity
                            })
                    
                    except Exception as e:
                        self.logger.error(f"Error processing product: {str(e)}")
                        continue
                        
            except Exception as e:
                self.logger.error(f"Error searching Amazon category {category}: {str(e)}")
                continue
                
        return products

    def search_snapdeal(self, image_features, categories):
        """Search Snapdeal for visually similar products and include ratings and delivery dates."""
        products = []
        for category in categories:
            try:
                # Construct URL with URL encoding
                import urllib.parse
                encoded_category = urllib.parse.quote(category)
                url = f"https://www.snapdeal.com/search?keyword={encoded_category}"
                self.driver.get(url)

                # Wait for product elements to load
                try:
                    WebDriverWait(self.driver, 15).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, '.product-tuple-image'))
                    )
                except TimeoutException:
                    self.logger.warning(f"No products found for category: {category}")
                    continue

                soup = BeautifulSoup(self.driver.page_source, 'html.parser')

                product_elements = soup.select('.product-tuple-inner')
                if not product_elements:
                    self.logger.warning(f"No product elements found for category: {category}")
                    continue

                for item in product_elements:
                    try:
                        title_elem = item.select_one('.product-title')
                        price_elem = item.select_one('.product-price')
                        img_elem = item.select_one('.product-image')
                        product_link = item.select_one('a.dp-widget-link')
                        rating_elem = item.select_one('.filled-stars')  # Extract ratings
                        delivery_elem = item.select_one('.delivery-detail')  # Extract delivery date

                        if not all([title_elem, price_elem, img_elem, product_link]):
                            continue

                        title = title_elem.text.strip()
                        try:
                            price_text = price_elem.text.strip().replace('Rs.', '').replace(',', '')
                            price = float(price_text)
                        except ValueError:
                            continue

                        img_url = img_elem.get('src') or img_elem.get('data-src') or img_elem.get('original-src')
                        if not img_url:
                            continue

                        product_url = product_link.get('href')
                        rating = rating_elem.text.strip() if rating_elem else 'No ratings'
                        delivery_date = delivery_elem.text.strip() if delivery_elem else 'Delivery info unavailable'

                        response = requests.get(img_url, timeout=10)
                        response.raise_for_status()
                        img_content = BytesIO(response.content)
                        product_features = self.image_analyzer.extract_features(img_content)

                        similarity = self.image_analyzer.compare_features(image_features, product_features)

                        if similarity > 0.5:
                            products.append({
                                'title': title,
                                'price': price,
                                'url': product_url,
                                'image_url': img_url,
                                'rating': rating,
                                'delivery_date': delivery_date,
                                'similarity': similarity
                            })
                    except Exception as e:
                        self.logger.error(f"Error processing Snapdeal product: {str(e)}")
                        continue
            except Exception as e:
                self.logger.error(f"Error searching Snapdeal category {category}: {str(e)}")
                continue
        return products

    def compare_images(self, hash1, hash2):
        """
        Compare two image hashes and return a similarity score.
        
        Parameters:
        hash1 (str): First image hash
        hash2 (str): Second image hash
        
        Returns:
        float: Similarity score between 0 and 1
        """
        try:
            # Convert hex hashes to binary
            bin_hash1 = bin(int(hash1, 16))[2:].zfill(64)
            bin_hash2 = bin(int(hash2, 16))[2:].zfill(64)
            
            # Calculate Hamming distance
            hamming_distance = sum(c1 != c2 for c1, c2 in zip(bin_hash1, bin_hash2))
            
            # Convert to similarity score (0-1 range)
            similarity = 1 - (hamming_distance / 64)
            
            return max(0, min(1, similarity))
        except Exception as e:
            self.logger.error(f"Error comparing image hashes: {str(e)}")
            return 0.0
